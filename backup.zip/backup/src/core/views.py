from flask import Blueprint, render_template, flash, redirect, request, url_for, jsonify
from flask_login import login_user, current_user, logout_user, login_required
from src.accounts.models import User
from src import bcrypt, db
import pandas 
from flask import Flask, render_template, request
from datetime import datetime
from sqlalchemy.exc import IntegrityError
import concurrent.futures
from argon2 import PasswordHasher
import asyncio
from threading import Thread


core_bp = Blueprint("core", __name__)

ph = PasswordHasher()


@core_bp.route("/")
@login_required
def home():
    print("home () >>>>>>>>>>>>>>>>>")
    user_list = User.query.filter_by(is_admin = False)
    # for i in user_list:
    #     db.session.delete(i)
    #     db.session.commit()
    #     print(i,"deleted")
    return render_template("accounts/home.html",user_list = user_list)

@core_bp.route('/delete/<int:user_id>', methods= ['GET'])
@login_required
def delete_user(user_id):
    user = User.query.filter_by(id=user_id).first()
    db.session.delete(user)
    db.session.commit()
    flash("User Deleted.", "success")
    return redirect(url_for("accounts.login"))


@core_bp.route('/update/<int:id>', methods=['GET', 'POST'])
@login_required
def update(id):
    user = User.query.filter_by(id=id).first()
    if request.method == 'POST':
        email = request.form['email']
        pass_word = request.form['password']
        if pass_word:
            password = bcrypt.generate_password_hash(pass_word)
            user.password = password
        user.email = email
        db.session.commit()
        return redirect(url_for('core.home'))
    return render_template("accounts/update.html",user_data = user)


@core_bp.route('/upload_file', methods=["GET", "POST"])
def upload():
    if request.method == 'POST':
        # Read the File using Flask request
        if request.files['file']:    
            file = request.files['file']
            # save file in local directory
            file.save(file.filename)
            # Parse the data as a Pandas DataFrame type
            df = pandas.read_excel(file)
            data = df.iterrows()
            # data = df.to_dict(orient='list')
            start = datetime.now()
            exist_user = User.query.all()
            exist_user_list = [user.email for user in exist_user]
            add_user_list = []

            for u_data in data:
                user_name = u_data[1]['Employee Name'].replace(" ","")+'@gmail.com'
                if user_name not in exist_user_list:
                    exist_user_list.append(user_name)
                    u_pass = u_data[1]['Employee Name'].replace(" ","")+'123'
                    add_user_list.append({'email': user_name, 'password': u_pass})

            # users_data = [{'email': i[1]['Employee Name'].replace(" ","")+"@gmail.com", 'password': i[1]['Employee Name'].replace(" ","")+'123'}for i in data]
            # for i in users_data:
            #     print(">>>>>>>>>>>>>>>>>>>>>",i)
            # db.session.bulk_insert_mappings(User, users_data)
            # db.session.commit()
            # end = datetime.now()
            # print("<><><<><><><<><><>>><><><><><><>",end-start)
            thread = Thread(target=run_background_task(add_user_list))
            thread.start()
            return redirect(url_for('core.home'))
            # return data.to_html()
    return render_template("accounts/upload_file.html")

async def background_task(user_data):
    # Simulate a time-consuming task
    for user in user_data:
        print(user['password'])
        n_user = User(email=user['email'],password=user['password'])
        db.session.add(n_user)
        db.session.commit()
    # db.session.bulk_insert_mappings(User, user_data)
    # db.session.commit()

    print("Background task <><><><><><><><><> completed")

def run_background_task(user_data):
    # Create an event loop and run the background task within it
    print(len(user_data))
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(background_task(user_data))